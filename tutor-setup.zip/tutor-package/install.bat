@echo off
chcp 65001 > nul
setlocal

echo.
echo ============================================
echo    수업 튜터 설치
echo ============================================
echo.

set "PKG=%~dp0"
pushd "%PKG%.."
set "TARGET=%CD%"
popd

echo  설치할 곳 : %TARGET%
echo.

if not exist "%TARGET%\Assets" goto NOTUNITY
if not exist "%TARGET%\ProjectSettings\ProjectVersion.txt" goto NOTUNITY

if exist "%TARGET%\.mcp.json" call :MCPWARN

if exist "%TARGET%\CLAUDE.md" (
  move /y "%TARGET%\CLAUDE.md" "%TARGET%\CLAUDE.md.bak" > nul
  echo  - 원래 있던 CLAUDE.md 는 CLAUDE.md.bak 으로 옮겼습니다.
)

copy /y "%PKG%files\CLAUDE.md" "%TARGET%\CLAUDE.md" > nul
if errorlevel 1 goto FAIL
echo  [1/5] CLAUDE.md                        튜터 규칙

copy /y "%PKG%files\syllabus.md" "%TARGET%\syllabus.md" > nul
if errorlevel 1 goto FAIL
echo  [2/5] syllabus.md                      수업 목차

if not exist "%TARGET%\.claude" mkdir "%TARGET%\.claude"
copy /y "%PKG%files\claude\settings.json" "%TARGET%\.claude\settings.json" > nul
if errorlevel 1 goto FAIL
echo  [3/5] .claude\settings.json            권한 잠금

xcopy "%PKG%files\Assets\Editor" "%TARGET%\Assets\Editor\" /e /i /y /q > nul
if errorlevel 1 goto FAIL
echo  [4/5] Assets\Editor                    에러 기록 · 제출 메뉴 · 튜터 업데이트 · 플레이 검사

if exist "%TARGET%\.gitignore" goto GITEXISTS
copy /y "%PKG%files\gitignore" "%TARGET%\.gitignore" > nul
if errorlevel 1 goto FAIL
echo  [5/5] .gitignore
goto GITDONE

:GITEXISTS
copy /y "%PKG%files\gitignore" "%TARGET%\.gitignore.tutor" > nul
echo  [5/5] .gitignore 가 이미 있어 .gitignore.tutor 라는 이름으로 두었습니다.

:GITDONE
if not exist "%TARGET%\.tutor" mkdir "%TARGET%\.tutor"
if not exist "%TARGET%\과제" mkdir "%TARGET%\과제"

echo.
echo ============================================
echo    설치 끝. 다음 두 가지를 하세요.
echo ============================================
echo.
echo   1. Unity 를 껐다가 다시 켭니다.
echo      Assets\Editor 에 새 파일이 생겨서 한 번 읽어야 합니다.
echo      다시 켜면 위 메뉴에 「제출」 이 생깁니다.
echo.
echo   2. 아래 폴더에서 Claude Code 를 실행합니다.
echo      %TARGET%
echo.
echo   제대로 됐는지 확인하는 법 :
echo   튜터에게 새 기능을 만들어 달라고 해보세요.
echo   완성 코드를 주지 않고 "무슨 일이 어떤 순서로 일어나야 하는지"
echo   를 먼저 물으면 정상입니다.
echo.
echo   과제 파일(과제1.md 등)은 디스코드 #과제 에서 받아
echo   위 폴더의 「과제」 폴더에 넣습니다.
echo.
echo   다음부터 튜터 업데이트는 Unity 메뉴 「제출 ▸ 튜터 업데이트」 로 합니다.
echo   이 설치는 처음 한 번만 하면 됩니다.
echo.
pause
exit /b 0

:MCPWARN
echo.
echo  [경고] 이 프로젝트에 .mcp.json 이 있습니다.
echo         이 파일이 있으면 튜터가 Unity 를 직접 조작할 수 있어서
echo         학생 대신 코드를 짜버릴 수 있습니다.
echo         학생 프로젝트에는 있으면 안 되는 파일입니다. 교수님께 알리세요.
echo.
exit /b 0

:NOTUNITY
echo.
echo  [실패] 여기는 Unity 프로젝트 폴더가 아닙니다.
echo.
echo  이 tutor-package 폴더를 Unity 프로젝트 폴더 안으로 옮긴 다음
echo  다시 실행하세요. 옳은 위치는 이렇습니다.
echo.
echo     내프로젝트\
echo        Assets\
echo        ProjectSettings\
echo        tutor-package\      ... 이 폴더가 여기 있어야 합니다
echo           install.bat
echo.
pause
exit /b 1

:FAIL
echo.
echo  [실패] 파일을 복사하지 못했습니다.
echo         Unity 나 편집기가 파일을 붙잡고 있을 수 있습니다.
echo         Unity 를 끄고 다시 실행해 보세요.
echo.
pause
exit /b 1
